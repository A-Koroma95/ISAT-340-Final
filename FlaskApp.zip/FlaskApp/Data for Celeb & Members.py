import sqlite3

conn = sqlite3.connect("celebrities.db")

cursor = conn.cursor()




sql1 = "insert into celebs values(?,?,?,?,?,?,?)"

data1 = ((1,"Angelina", "Jolie",40,"angie@hollywood.us",'../static/Jolie.jpg',"American actress and filmmaker, Born and raised in Los Angeles, California."),(2, "Brad","Pitt",51,"brad@hollywood.us",'../static/Pitt.jpg',"American Actor Acadamy award winner, Born in Shawnee, Oklahoma"),(3,"Snow", "White",21,"sw@disney.org",'../static/White.jpg',"Disney princess whos roommates with 7 dwarves."),(4,"Darth", "Vader",29,"dv@darkside.me",'../static/Vader.jpg',"Formely known as Anakin Skywalker. I am your FATHER!."),
(5,"Taylor", "Swift",25,'ts@1989.us','../static/Swift.jpg',"American singer and songwriter, Born in West Reading, Pennsylvania"),(6,"Beyonce", "Knowles",34,"beyonce@jayz.me",'../static/Knowles.jpg',"American singer and songwriter, Born and Raised in Houston, Texas"),(7,"Selena", "Gomez",23,"selena@hollywood.us",'../static/Gomez.jpg',"American singer and actress. Born and raised in San Antonio"),(8,"Stephen", "Curry",27,"steph@golden.bb",'../static/Curry.jpg',"NBA basketball player,member of the Golden State Warriors and greatest shooter all time"))
cursor.executemany(sql1, data1)




sql = "insert into members values(?,?,?,?,?,?)"
data = ((1, "Abass","Koroma",22,'Sesay2ax@dukes.jmu.edu','Born in Freetown, Sierra Leone and raised in Loudoun County Virginia. '),
         (2, "Johnny","Duenas",21,"Duenasje@dukes.jmu.edu", "I was born on April 17th, 2001 in Farifax, VA."))
cursor.executemany(sql, data)

sql2= "insert into member_login values(?, ?, ?)"
data2=((1, "Akoroma", "Candy"),(2,"Jduenas","Gum"))
cursor.executemany(sql2,data2)

 
conn.commit()
conn.close()
