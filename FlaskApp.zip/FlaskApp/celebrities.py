import sqlite3

conn = sqlite3.connect("celebrities.db")

cursor = conn.cursor()

conn.close()



import sqlite3

conn = sqlite3.connect("celebrities.db")

cursor = conn.cursor()


sql1 = "create table celebs(celebID INTEGER PRIMARY KEY, firstname TEXT, lastname TEXT, age INTEGER, email TEXT, photo TEXT, bio TEXT)"
sql2 = "create table members(memberID, firstname TEXT, lastname TEXT, age INTEGER, email TEXT, bio TEXT)"

cursor.execute(sql1)
cursor.execute(sql2)

conn.commit()
conn.close()

import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()

sql1 = "insert into celebs values(?,?,?,?,?,?,?)"
data = ((1, "Angelina", "Jolie","40","angie@hollywood.us","https://s3.amazonaws.com/isat3402021/aj.jpg", "I love coding"), (2, "Brad", "Pitt", "51", "brad@hollywood.us","https://s3.amazonaws.com/isat3402021/aj.jpg","I was born in Shawnee, Oklahoma"), (3,"Snow", "White", "21", "sw@disney.org","https://s3.amazonaws.com/isat3402021/aj.jpg", "I am a disney princess"), (4, "Darth", "Vader", "29","dv@darkside.me","https://s3.amazonaws.com/isat3402021/aj.jpg", "I am your FATHER"),(5, "Taylor", "Swift", "25", "ts@1989.us", "https://s3.amazonaws.com/isat3402021/aj.jpg","I was born in West Reading, Pennsylvania"),(6, "Beyonce","Knowles","34", "beyonce@jayz.me", "https://s3.amazonaws.com/isat3402021/aj.jpg", "I was born in Houston, Texas"),(7, "Selena","Gomez", "23", "selena@hollywood.us","https://s3.amazonaws.com/isat3402021/aj.jpg", "I was born in San Antonio, Texas"),(8,"Stephen","Curry","27","step@golden.bb","https://s3.amazonaws.com/isat3402021/aj.jpg", "I am the greatest shooter all time")) 
cursor.executemany(sql1, data)

conn.commit()
conn.close()


import sqlite3
conn= sqlite3.connect("celebrities.db")
cursor=conn.cursor()
sql = "select* from celebs"
cursor.execute(sql)


rows = cursor.fetchall()

for row in rows:
    print(row)
conn.close()
